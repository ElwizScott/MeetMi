package ModelClass;

import com.example.meetmi.Users;

public interface UserCallback {
    void onCallback(Users user);
}
