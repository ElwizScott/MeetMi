package com.example.meetmi.customAdapter;

public interface OnItemClickListener {
    void onItemClick(int position);
}

